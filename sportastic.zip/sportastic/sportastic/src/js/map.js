export default {
  trainingType: {
    power: "כוח",
    functional: "פונקציונלי",
    pilates: "פילאטיס",
    aerobic: "אירובי",
    ber: "בר",
  },
  days: ["ראשון", "שני", "שלישי", "רביעי", "חמישי", "שישי", "שבת"],
};
